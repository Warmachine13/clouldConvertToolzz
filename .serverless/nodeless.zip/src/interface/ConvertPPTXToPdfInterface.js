import fileconvert from "office-to-pdf";

class ConvertPPTXToPdfInterface {
  #pptxConvert = fileconvert;
  #stream = null;
  constructor(stream) {
    this.#stream = stream;
  }

  async convert() {
    return await this.#pptxConvert(this.#stream);
  }
}

export { ConvertPPTXToPdfInterface };
