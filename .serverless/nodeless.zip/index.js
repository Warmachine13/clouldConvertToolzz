import { ConvertPPTXToPdfInterface } from "./src/interface/ConvertPPTXToPdfInterface";
import { AWSInterface } from "./src/interface/AWSInterface.js";

// const { Lambda } = require("aws-sdk");
// const lambda = new Lambda({
//   apiVersion: "v0.0.1",
//   endpoint: process.env.IS_OFFLINE
//     ? "http://localhost:3002"
//     : "<YOUR_AWS_ENDPOINT>",
// });

exports.handle = async ({ Records: records }, context, callback) => {
  console.log("entrou");
  try {
    const responses = await Promise.all(
      records.map(async (record) => {
        const cloudConvert = new ConvertPPTXToPdfInterface(record);
        try {
          const response = await cloudConvert.convert();
          // const awsInterface = new AWSInterface();
          // const object = await awsInterface.putObject(
          //   response,
          //   "convert-pdf-img",
          //   `${record.name}.pdf`
          // );
          callback(null, {
            statusCode: 200,
            body: JSON.stringify({
              message: "Convertion done",
              url: response,
            }),
          });
        } catch (error) {}
      })
    );
    return {
      statusCode: 301,
      body: JSON.stringify({ responses }),
    };
  } catch (error) {
    return error;
  }
};

// export { handler };
